import occlusion

editor = occlusion.VideoEditor(20, 0, 17, 17, 300)
editor.edit('/Users/bohdansynytskyi/research/Actor_01/output.mp4', "/Users/bohdansynytskyi/desktop/noisyName.mp4")
